﻿namespace BuiP3.Models
{
    public class CoursesModel
    {
        public string pageTitle { get; set; }
        public List<string> allCourses { get; set; } // Combined list from degrees/minors
    }
}