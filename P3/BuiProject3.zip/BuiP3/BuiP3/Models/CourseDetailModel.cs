﻿namespace BuiP3.Models
{
    public class CourseDetailModel
    {
        public string pageTitle { get; set; }
        public string courseID { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public string prerequisites { get; set; }
    }
}