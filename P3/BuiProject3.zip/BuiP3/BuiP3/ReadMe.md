Plugins Used: jQuery UI, DataTables, Sticky navigation bar  on the Employment datable  for easier access while scrolling.

Above and beyond:
I added the Map API on the employment page
Navigation Meny is highlight on the active page
I make a course detail page, show detail of whatever course they want to look at, and if that course has a prerequisites course