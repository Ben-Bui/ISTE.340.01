﻿namespace BuiP3.Models
{
    public class AboutModel
    {
        public string title { get; set; }
        public string description { get; set; }
        public string quote { get; set; }
        public string quoteAuthor { get; set; }
        public string pageTitle { get; set; }
    }
}
